const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Static files
app.use(express.static(path.join(__dirname, '.')));

// =====================
// API ROUTES
// =====================

// Contact form submission
app.post('/api/contact', (req, res) => {
  const { fname, lname, email, company, role, message, timestamp } = req.body;

  // Basic validation
  if (!fname || !lname || !email) {
    return res.status(400).json({ success: false, error: 'Missing required fields' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, error: 'Invalid email address' });
  }

  const submission = {
    id: `sub_${Date.now()}`,
    fname, lname, email, company, role, message,
    timestamp: timestamp || new Date().toISOString(),
    ip: req.ip
  };

  // Log to file (replace with DB / email service in production)
  const logsDir = path.join(__dirname, 'logs');
  if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir);

  const logFile = path.join(logsDir, 'submissions.jsonl');
  fs.appendFileSync(logFile, JSON.stringify(submission) + '\n');

  console.log(`[Contact] New submission from ${email} — ${new Date().toISOString()}`);

  // In production: send email via SendGrid / Resend / Postmark here
  // await sendEmail({ to: 'hello@runtic.ai', subject: `New lead: ${fname} ${lname}`, ...submission })

  return res.status(200).json({
    success: true,
    message: 'Thank you! We will reach out within 24 hours.',
    id: submission.id
  });
});

// Careers apply endpoint
app.post('/api/careers/apply', (req, res) => {
  const { name, email, role, linkedin, message } = req.body;

  if (!name || !email || !role) {
    return res.status(400).json({ success: false, error: 'Missing required fields' });
  }

  const application = {
    id: `app_${Date.now()}`,
    name, email, role, linkedin, message,
    timestamp: new Date().toISOString()
  };

  const logsDir = path.join(__dirname, 'logs');
  if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir);
  fs.appendFileSync(path.join(logsDir, 'applications.jsonl'), JSON.stringify(application) + '\n');

  console.log(`[Careers] Application from ${email} for ${role}`);

  return res.status(200).json({ success: true, message: 'Application received!', id: application.id });
});

// Health check (for hosting platforms like Railway, Render, Fly.io)
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'runtic-web', ts: new Date().toISOString() });
});

// Catch-all — serve index.html for SPA routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🤖 Runtic web server running`);
  console.log(`   Local:   http://localhost:${PORT}`);
  console.log(`   Env:     ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
