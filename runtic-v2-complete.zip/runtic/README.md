# Runtic Website

**The New Way of Working™** — Agentic AI company website with full frontend + Node.js/Express backend.

---

## Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS (no framework needed) |
| Backend | Node.js + Express |
| Fonts | Cormorant Garamond · Outfit · Space Mono (Google Fonts) |
| Deployment | Vercel / Railway / Render / Fly.io / Any VPS |

---

## Local Development

```bash
# Install dependencies
npm install

# Run dev server (with auto-reload)
npm run dev

# Run production server
npm start
```

Open: http://localhost:3000

---

## Deployment Options

### Option 1 — Vercel (Recommended, Free Tier)
```bash
npm install -g vercel
vercel
```
Add `vercel.json` in root:
```json
{
  "version": 2,
  "builds": [{ "src": "server.js", "use": "@vercel/node" }],
  "routes": [{ "src": "/(.*)", "dest": "server.js" }]
}
```

### Option 2 — Railway (Easiest, auto-detects Node)
1. Push to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Railway auto-detects `package.json` and deploys

### Option 3 — Render (Free tier)
1. Push to GitHub
2. render.com → New Web Service → Connect repo
3. Build command: `npm install`
4. Start command: `npm start`

### Option 4 — Fly.io (Global edge)
```bash
npm install -g flyctl
fly launch
fly deploy
```

### Option 5 — Static hosting (Netlify / GitHub Pages)
The frontend works as a pure static site. For contact form:
- Use Netlify Forms (add `netlify` attribute to form)
- Or use Formspree / EmailJS for form handling

---

## Environment Variables

Create `.env` file:
```
PORT=3000
NODE_ENV=production
CONTACT_EMAIL=hello@runtic.ai

# Optional — add email service
SENDGRID_API_KEY=your_key_here
RESEND_API_KEY=your_key_here
```

---

## Production Email Setup

In `server.js`, replace the file logger with a real email service:

```js
// Using Resend (recommended)
const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

await resend.emails.send({
  from: 'noreply@runtic.ai',
  to: 'hello@runtic.ai',
  subject: `New lead: ${fname} ${lname}`,
  html: `<p>${JSON.stringify(submission, null, 2)}</p>`
});
```

---

## Pages / Sections

| Section | Anchor |
|---------|--------|
| Hero | `#home` |
| How it Works | `#agents` |
| About + Vision | `#about` |
| Agent Roles | `#roles` |
| Careers | `#careers` |
| Contact | `#contact` |

---

## Custom Domain

After deploying to any platform, add your custom domain:
1. Buy `runtic.ai` on Namecheap / Porkbun
2. Point DNS to your hosting platform
3. Enable HTTPS (all platforms do this automatically)

---

## Logo Files

- `public/images/favicon.svg` — browser tab icon
- Logo is inline SVG in `index.html` (scalable, no file needed)
- Gold hex: `#C9A84C` | Dark gold: `#E2C97E` | Black: `#0a0a0a`

---

*Built with Runtic — The New Way of Working™*
